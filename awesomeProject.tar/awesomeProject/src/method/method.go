package method


func main()  {
	var  re= [...]int{1, 2,3}
	var s []int
	for _,v:=range re{
		for _,t:=range s{
			if v>=t{
				s= append(s, v)
			}else{
				tmp := s
				var sg []int
				sg=append(sg,v)
				sg=append(sg,tmp...)
				break
			}
		}
	}
}